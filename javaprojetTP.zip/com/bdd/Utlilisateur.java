package com.bdd;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.beans.User;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
public class Utlilisateur {
	private java.sql.Connection connexion;
	
	private void loadDB() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}catch(ClassNotFoundException e) {
		System.out.println("erreur");
	}
		
		try {
			connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/freelost","root","");
		}catch(SQLException e) {
			System.out.println("erreur");
			e.printStackTrace();
		}
	}
	
	//recuperer un utilisateur de la base de donnees
	public List <User> recupererUtilisateurs(){
		
		List <User> users = new ArrayList<User>();
		
		//chargement du driver
		
		//connexion a la bd
		
		java.sql.Statement statement = null;
		java.sql.ResultSet result = null;
		this.loadDB();
		
		try {
			statement =  connexion.createStatement();
			
			//execution de la requete
			result = statement.executeQuery("SELECT adresse,emailUtilisateur,nomUtilisateur,profil,telephone,typeUtilisateur FROM utilisateur;");
			System.out.println("connection ok");
			while(result.next()) {
				String adresse = result.getString("adresse");
				String email = result.getString("emailUtilisateur");
				String nom = result.getString("nomUtilisateur");
				String type = result.getString("typeUtilisateur");
				String profil = result.getString("profil");
				String telephone =  result.getString("telephone");
				
				User user = new User();
				user.setAdresse(adresse);
				user.setEmail(email);
				user.setNom(nom);
				user.setProfil(profil);
				user.setTelephone(telephone);
				user.setProfil(profil);
				//user.setCon("ok");
				users.add(user);
			}
			
		}catch(SQLException e) {
		
			System.out.println("error au niveau de la requete ");
		}finally {
			//fermer la connection
			try {
				if(result != null)
					result.close();
				if(statement != null)
					statement.close();
				if(connexion != null)
					connexion.close();
			}catch(SQLException ignore) {
				
			}
		}
		
		
		return users;
	}
	
	//Ajouter un utilisateur a la BD
	
	
	public void addUser(User user) {
		this.loadDB();
		System.out.println("connexion pour ajout");
		String type = "user";
		try {
			java.sql.PreparedStatement prepare = connexion.prepareStatement("INSERT INTO utilisateur(adresse,emailUtilisateur,telephone,nomUtilisateur,typeUtilisateur,pass) VALUES(?,?,?,?,?,?);");
			int tel = Integer.parseInt(user.getTelephone());
			prepare.setString(1, user.getAdresse());
			prepare.setString(2, user.getEmail());
			prepare.setInt(3, tel);
			prepare.setString(4, user.getNom());
			prepare.setString(5, type);
			prepare.setString(6, user.getPass());
			prepare.execute();
			System.out.println("ajout effectuer avec succes");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("erreur pour ajout");
			System.out.println(user.getTelephone());
			e.printStackTrace();
		}
	}
	
}

