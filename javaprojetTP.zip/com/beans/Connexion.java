package com.beans;

import java.util.List;

import com.dao.DaoFactory;
import com.dao.UtilisateurDao;

public class Connexion {
	private UtilisateurDao utilisateurDao;
	private List<User> users;
	private ConnectionResponse response;
	public void init() {
		DaoFactory daofactory = DaoFactory.getInstance();
		this.utilisateurDao = daofactory.getUtilisateurDao();
	}
	public ConnectionResponse check(String username, String pass) {
		this.init();
		users = this.utilisateurDao.lister();
		for(User user: users) {
			if( (user.getNom().equals(username)||user.getEmail().equals(username)) && user.getPass().equals(pass) ) {
				response = new ConnectionResponse(user, true);
				return response;
			}	
		}
		
		return new ConnectionResponse(null, false);
	
}
}
