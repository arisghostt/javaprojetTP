package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.beans.User;

public class UtilisateurDaoImpl implements UtilisateurDao {
	private DaoFactory daoFactory;

	public UtilisateurDaoImpl(DaoFactory daoFactory) {
		this.daoFactory = daoFactory;
	}
	
	
	public void addUser(User user) {
		Connection connexion = null;
		PreparedStatement prepare = null;
		
		String type = "user";
		try {
			connexion = daoFactory.getConnection();
			prepare = connexion.prepareStatement("INSERT INTO utilisateur(adresse,emailUtilisateur,telephone,nomUtilisateur,typeUtilisateur,pass) VALUES(?,?,?,?,?,?);");
			int tel = Integer.parseInt(user.getTelephone());
			prepare.setString(1, user.getAdresse());
			prepare.setString(2, user.getEmail());
			prepare.setInt(3, tel);
			prepare.setString(4, user.getNom());
			prepare.setString(5, type);
			prepare.setString(6, user.getPass());
			prepare.execute();
			System.out.println("ajout effectuer avec succes");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("erreur pour ajout");
			System.out.println(user.getTelephone());
			e.printStackTrace();
		}
	}
	
public List <User> lister(){
		
		List <User> users = new ArrayList<User>();
	
		Connection connexion = null;
		Statement statement = null;
		ResultSet result = null;
		
		
		try {
			connexion = daoFactory.getConnection();
			statement =  connexion.createStatement();
			
			//execution de la requete
			result = statement.executeQuery("SELECT adresse,emailUtilisateur,nomUtilisateur,profil,telephone,typeUtilisateur,pass FROM utilisateur;");
			System.out.println("connection ok");
			while(result.next()) {
				String adresse = result.getString("adresse");
				String email = result.getString("emailUtilisateur");
				String nom = result.getString("nomUtilisateur");
				String type = result.getString("typeUtilisateur");
				String profil = result.getString("profil");
				String telephone =  result.getString("telephone");
				String pass = result.getString("pass");
				
				User user = new User();
				user.setAdresse(adresse);
				user.setEmail(email);
				user.setNom(nom);
				user.setProfil(profil);
				user.setTelephone(telephone);
				user.setProfil(profil);
				user.setPass(pass);
				//user.setCon("ok");
				users.add(user);
			}
			
		}catch(SQLException e) {
		
			System.out.println("error au niveau de la requete ");
		}finally {
			//fermer la connection
			try {
				if(result != null)
					result.close();
				if(statement != null)
					statement.close();
				if(connexion != null)
					connexion.close();
			}catch(SQLException ignore) {
				
			}
		}
		
		
		return users;
	}
}
