package com.dao;

import java.util.List;

import com.beans.User;

public interface UtilisateurDao {
	void addUser(User user);
	List<User> lister(); 
}
